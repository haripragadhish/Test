import React from "react";

const ViewComponent = ({ viewData, handleCompleted }) => {
  console.log(viewData);
  return (
    <div style={{ border: "1px solid", textAlign: "center" }}>
      {viewData?.id}-{viewData?.title}
      <br />
      <button onClick={() => handleCompleted(viewData)}>Completed</button>
    </div>
  );
};

export default ViewComponent;
