import React, { useState, useEffect } from "react";
import axios from "axios";

const ListComponent = ({ handleClick, completedData }) => {
  const [data, setData] = useState([]);

  const getData = async () => {
    let result = await axios.get("https://jsonplaceholder.typicode.com/posts");
    setData(result.data);
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <div>
      <div style={{ border: "1px solid" }}>
        <ul>
          {data.map((d, index) => {
            return (
              <li
                key={index}
                onClick={() => handleClick(d)}
                style={{
                  textDecoration:
                    d.id === completedData.id ? "line-through" : "none",
                }}
              >
                {d.id}-{d.title}
                <hr />
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
};

export default ListComponent;
