import ListComponent from "./List";
import ViewComponent from "./View";
import React, { useState } from "react";

function App() {
  const [viewData, setViewData] = useState();
  const [completedData, setCompletedData] = useState([]);

  const handleCompleted = (data) => {
    setCompletedData(data);
  };

  const handleClick = (data) => {
    setViewData(data);
    console.log(data);
  };
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr" }}>
      <ListComponent handleClick={handleClick} completedData={completedData} />
      <ViewComponent viewData={viewData} handleCompleted={handleCompleted} />
    </div>
  );
}

export default App;
